.
├── agents/
│   └── dqn.py                 # ✅ Agent DQN avec replay buffer intégré
├── configs/
│   └── dqn_breakout.yaml      # ✅ Configuration (hyperparamètres Nature paper)
├── env/
│   └── wrappers.py            # ✅ Preprocessing Atari (NoOp, FireReset, etc.)
├── memory/
│   └── replay_buffer.py       # ✅ Experience replay buffer
├── networks/
│   └── atari_cnn.py           # ✅ CNN architecture (Nature paper)
├── utils/
│   ├── config.py              # ✅ Parser YAML → DQNConfig
│   ├── eval_utils.py          # ✅ Fonction d'évaluation multi-épisodes
│   ├── logger.py              # ✅ Logger CSV pour métriques
│   ├── plot_training.py       # ✅ Génération des graphiques d'entraînement
│   └── seed.py                # ✅ Fixation du seed pour reproductibilité
├── train.py                   # ✅ Script d'entraînement principal
└── eval.py                    # ✅ Script d'évaluation avec vidéos