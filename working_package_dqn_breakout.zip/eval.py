#!/usr/bin/env python3
# eval.py
import argparse
import os
from datetime import datetime
import torch
from gymnasium.wrappers import RecordVideo

from env.wrappers import make_atari_env
from agents.dqn import DQNAgent, DQNConfig
from utils.eval_utils import evaluate


def make_eval_env_with_video(env_id: str, out_dir: str, run_name: str = None, every_ep: bool = True):
    """Build Atari env for evaluation with video recording
    
    Args:
        env_id: Atari environment ID
        out_dir: Base output directory
        run_name: Unique name for this evaluation run (default: timestamp)
        every_ep: Record every episode if True, else every 10th
    """
    # Create unique subdirectory for this run
    if run_name is None:
        run_name = datetime.now().strftime("%Y%m%d-%H%M%S")
    
    video_dir = os.path.join(out_dir, "videos", run_name)
    os.makedirs(video_dir, exist_ok=True)
    
    env = make_atari_env(env_id, training=False, render_mode="rgb_array")
    env = RecordVideo(
        env,
        video_folder=video_dir,
        episode_trigger=(lambda ep: True) if every_ep else (lambda ep: ep % 10 == 0),
        name_prefix="eval"
    )
    return env


def main():
    parser = argparse.ArgumentParser(description="Evaluate a trained DQN agent")
    parser.add_argument("--env_id", type=str, default="ALE/Breakout-v5",
                       help="Atari environment ID")
    parser.add_argument("--checkpoint", type=str, required=True,
                       help="Path to checkpoint file")
    parser.add_argument("--episodes", type=int, default=10,
                       help="Number of evaluation episodes")
    parser.add_argument("--out_dir", type=str, default="runs/eval",
                       help="Output directory for videos")
    parser.add_argument("--run_name", type=str, default=None,
                       help="Unique name for this eval run (default: timestamp)")
    parser.add_argument("--record_all", action="store_true",
                       help="Record all episodes (default: only first)")
    parser.add_argument("--seed", type=int, default=0,
                       help="Random seed")
    args = parser.parse_args()
    
    os.makedirs(args.out_dir, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Generate unique run name if not provided
    if args.run_name is None:
        # Extract checkpoint info for better naming
        ckpt_name = os.path.basename(args.checkpoint).replace(".pt", "")
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        args.run_name = f"{ckpt_name}_{timestamp}"
    
    # Load checkpoint to get config
    print(f"📦 Loading checkpoint: {args.checkpoint}")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    
    # Reconstruct config
    cfg_dict = checkpoint.get("cfg", {})
    cfg = DQNConfig(**cfg_dict)
    cfg.device = device  # Override device
    
    # Create agent and load weights
    agent = DQNAgent(cfg)
    agent.load(args.checkpoint)
    
    print(f"🤖 Agent loaded (step={agent.step_count:,}, updates={agent.update_count:,})")
    
    # Evaluation with video recording
    def env_fn():
        return make_eval_env_with_video(
            args.env_id, 
            args.out_dir, 
            run_name=args.run_name,
            every_ep=args.record_all
        )
    
    print(f"🎮 Evaluating {args.env_id} for {args.episodes} episodes...")
    print(f"📹 Videos will be saved to: {os.path.join(args.out_dir, 'videos', args.run_name)}")
    
    results = evaluate(
        agent=agent,
        env_fn=env_fn,
        num_episodes=args.episodes,
        epsilon_eval=cfg.eval_epsilon,
        seed=args.seed
    )
    
    print(
        f"\n✅ Evaluation complete!\n"
        f"  Mean Return: {results['eval_return_mean']:.2f} ± {results['eval_return_std']:.2f}\n"
        f"  Min/Max: [{results['eval_return_min']:.2f}, {results['eval_return_max']:.2f}]\n"
        f"  Mean Episode Length: {results['eval_len_mean']:.1f}\n"
        f"🎥 Videos saved in: {os.path.join(args.out_dir, 'videos', args.run_name)}"
    )


if __name__ == "__main__":
    main()