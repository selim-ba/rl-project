#!/usr/bin/env python3
# train.py
import argparse
import time
import yaml
from pathlib import Path
from datetime import datetime

import torch

from env.wrappers import make_atari_env
from agents.dqn import DQNAgent
from utils.config import load_yaml, yaml_to_dqn_config, _get_nested
from utils.eval_utils import evaluate
from utils.logger import CSVLogger
from utils.seed import set_seed


def parse_args():
    p = argparse.ArgumentParser(description="Train DQN on Atari")
    
    # Config file
    p.add_argument("--config", type=str, default="configs/dqn_breakout.yaml",
                   help="Path to YAML config file")
    
    # CLI overrides (optional)
    p.add_argument("--env_id", type=str, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--total_steps", type=int, default=None)
    p.add_argument("--eval_interval", type=int, default=None)
    p.add_argument("--eval_episodes", type=int, default=None)
    p.add_argument("--save_interval", type=int, default=None)
    p.add_argument("--runs_dir", type=str, default="runs")
    
    return p.parse_args()


def build_run_dir(runs_dir: str, env_id: str, seed: int) -> Path:
    """Create timestamped run directory"""
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_env = env_id.replace("/", "_").replace("-", "_")
    run_dir = Path(runs_dir) / f"dqn-{safe_env}-seed{seed}-{ts}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def main():
    args = parse_args()
    
    # Load YAML config
    cfg_yaml = load_yaml(args.config)
    
    # Merge YAML + CLI (CLI takes precedence)
    env_id = args.env_id or _get_nested(cfg_yaml, "env_id", default="ALE/Breakout-v5")
    seed = args.seed if args.seed is not None else _get_nested(cfg_yaml, "seed", default=0)
    total_steps = args.total_steps or _get_nested(cfg_yaml, "train", "total_steps", default=10_000_000)
    eval_interval = args.eval_interval or _get_nested(cfg_yaml, "train", "eval_interval", default=250_000)
    eval_episodes = args.eval_episodes or _get_nested(cfg_yaml, "train", "eval_episodes", default=10)
    save_interval = args.save_interval or _get_nested(cfg_yaml, "train", "save_interval", default=250_000)
    
    # Set global seed
    set_seed(seed)
    
    # Create environment to get observation shape
    env = make_atari_env(env_id, training=True)
    obs, info = env.reset(seed=seed)
    obs_shape = env.observation_space.shape
    n_actions = env.action_space.n
    env.action_space.seed(seed)
    
    # Build DQN config from YAML
    cfg = yaml_to_dqn_config(cfg_yaml, obs_shape, n_actions)
    
    # Create run directory
    run_dir = build_run_dir(args.runs_dir, env_id, seed)
    
    # Save config for traceability
    with open(run_dir / "config.yaml", "w") as f:
        yaml.safe_dump(cfg_yaml, f, sort_keys=False)
    
    # Setup logging
    logger = CSVLogger(str(run_dir))
    # Initialize with all columns
    logger.log({
        "step": 0, "updates": 0, "loss": None, "q_max": None, "epsilon": None, "fps": None,
        "episode": 0, "episode_return": None, "episode_length": None,
        "eval_return_mean": None, "eval_return_std": None,
        "eval_return_min": None, "eval_return_max": None, "eval_len_mean": None
    })
    
    # Create agent
    agent = DQNAgent(cfg)
    
    # Training loop
    step = 0
    episode_idx = 0
    ep_return = 0.0
    ep_len = 0
    
    t0 = time.time()
    last_report_t = t0
    last_report_step = 0
    
    print(f"🎮 Training DQN on {env_id}")
    print(f"📁 Run directory: {run_dir}")
    print(f"🎯 Total steps: {total_steps:,}")
    
    while step < total_steps:
        # Select action
        action = agent.act(obs, eval_mode=False)
        
        # Environment step
        next_obs, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated
        step += 1
        ep_return += float(reward)
        ep_len += 1
        
        # Store transition
        agent.observe(obs, action, reward, next_obs, done)
        
        # Update agent
        update_out = agent.update()
        
        # Log update metrics immediately when available
        if update_out:
            logger.log({
                "step": step,
                "updates": update_out["updates"],
                "loss": update_out["loss"],
                "q_max": update_out["q_max"],
                "epsilon": update_out["epsilon"]
            })

        # Separate periodic FPS logging
        if step % 1_000 == 0:
            now = time.time()
            dt = now - last_report_t
            dsteps = step - last_report_step
            fps = dsteps / dt if dt > 0 else 0.0
            last_report_t = now
            last_report_step = step
            
            logger.log({
                "step": step,
                "fps": fps,
                "epsilon": agent._epsilon()
            })

        
        # Episode end
        if done:
            episode_idx += 1
            logger.log({
                "step": step,
                "episode": episode_idx,
                "episode_return": ep_return,
                "episode_length": ep_len
            })
            
            if episode_idx % 10 == 0:
                print(f"Episode {episode_idx} | Step {step:,} | Return: {ep_return:.1f} | Length: {ep_len}")
            
            obs, info = env.reset()
            ep_return = 0.0
            ep_len = 0
        else:
            obs = next_obs
        
        # Periodic evaluation
        if step % eval_interval == 0 or step == total_steps:
            print(f"\n📊 Evaluating at step {step:,}...")
            eval_stats = evaluate(
                env_fn=lambda: make_atari_env(env_id, training=False),
                agent=agent,
                num_episodes=eval_episodes,
                epsilon_eval=cfg.eval_epsilon,
                seed=seed
            )
            logger.log({"step": step, **eval_stats})
            print(f"   Mean return: {eval_stats['eval_return_mean']:.2f} ± {eval_stats['eval_return_std']:.2f}\n")
        
        # Periodic checkpoint
        if step % save_interval == 0 or step == total_steps:
            ckpt_path = run_dir / f"ckpt_{step}.pt"
            agent.save(str(ckpt_path))
            print(f"💾 Checkpoint saved: {ckpt_path}")
    
    # Final save
    agent.save(str(run_dir / "final.pt"))
    env.close()
    logger.close()
    
    print(f"\n✅ Training complete!")
    print(f"📁 Results saved to: {run_dir}")


if __name__ == "__main__":
    main()