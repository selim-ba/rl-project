# utils/plot_training.py
from __future__ import annotations
import os
import sys
import pandas as pd
import matplotlib.pyplot as plt

plt.style.use("seaborn-v0_8-whitegrid")


def _ema(series: pd.Series, alpha: float = 0.1) -> pd.Series:
    """Compute exponential moving average for smoother curves."""
    return series.ewm(alpha=alpha, adjust=False).mean()


def plot_training(csv_path: str, out_dir: str | None = None, smooth_alpha: float = 0.2):
    """
    Reads metrics.csv produced by train.py and saves key training/eval plots.

    Args:
        csv_path: path to metrics.csv
        out_dir: folder to save .png files (defaults to same folder as csv)
        smooth_alpha: EMA smoothing factor (0 = no smoothing, 0.2 typical)
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    out_dir = out_dir or os.path.dirname(csv_path)
    os.makedirs(out_dir, exist_ok=True)

    df = pd.read_csv(csv_path)
    print(f"Loaded {len(df)} rows from {csv_path}")

    def save_plot(x, y, ylabel, title, filename, ema=True):
        if x not in df.columns or y not in df.columns:
            return
        plt.figure(figsize=(6, 4))
        xs = df[x]
        ys = _ema(df[y], smooth_alpha) if ema else df[y]
        plt.plot(xs, ys, lw=1.5)
        plt.xlabel(x)
        plt.ylabel(ylabel)
        plt.title(title)
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, filename))
        plt.close()

    # ------------------ Training stats ------------------
    save_plot("updates", "loss", "Huber Loss", "Training Loss", "loss.png")
    save_plot("updates", "q_max", "Mean max Q(s,a)", "Q-value over time", "q_max.png")
    save_plot("step", "epsilon", "ε", "Exploration Schedule", "epsilon.png", ema=False)
    save_plot("episode", "episode_return", "Return", "Training Episode Return", "train_return.png")
    save_plot("episode", "episode_length", "Length", "Training Episode Length", "train_length.png")

    # ------------------ Evaluation stats ------------------
    if "eval_return_mean" in df.columns:
        plt.figure(figsize=(6, 4))
        sub = df.dropna(subset=["eval_return_mean"])
        if not sub.empty:
            plt.plot(sub["step"], sub["eval_return_mean"], label="mean", lw=2)
            if "eval_return_std" in sub.columns:
                up = sub["eval_return_mean"] + sub["eval_return_std"]
                down = sub["eval_return_mean"] - sub["eval_return_std"]
                plt.fill_between(sub["step"], down, up, alpha=0.2, label="±1 std")
            plt.xlabel("env steps")
            plt.ylabel("Eval Return")
            plt.title("Evaluation Performance")
            plt.legend()
            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "eval_return.png"))
        plt.close()

    print(f"Saved plots to {out_dir}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python utils/plot_training.py <path/to/metrics.csv> [smooth_alpha]")
        sys.exit(1)

    csv_path = sys.argv[1]
    smooth_alpha = float(sys.argv[2]) if len(sys.argv) > 2 else 0.2
    plot_training(csv_path, smooth_alpha=smooth_alpha)
